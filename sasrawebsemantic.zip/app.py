from flask import Flask, jsonify, render_template
from rdflib import Graph, Namespace
from rdflib.namespace import RDF, RDFS

app = Flask(__name__, template_folder="templates")

# Load RDF data
graph = Graph()
graph.parse("data/laundry_data.ttl", format="turtle")

# Define namespaces
EX = Namespace("http://example.org/e-laundry#")
SCHEMA = Namespace("http://schema.org/")

# Endpoint to get all laundry services
@app.route("/api/laundry")
def get_laundry_services():
    query = """
    PREFIX ex: <http://example.org/e-laundry#>
    PREFIX schema: <http://schema.org/>
    SELECT ?name ?address ?locatedIn ?serviceOffered
    WHERE {
        ?laundry a schema:LaundryBusiness ;
                 schema:name ?name ;
                 schema:address ?address ;
                 schema:locatedIn ?locatedIn ;
                 schema:serviceOffered ?serviceOffered .
    }
    """
    results = graph.query(query, initNs={"schema": SCHEMA, "ex": EX})
    services = [
        {
            "name": str(row.name),
            "address": str(row.address),
            "locatedIn": str(row.locatedIn),
            "serviceOffered": str(row.serviceOffered),
        }
        for row in results
    ]
    return jsonify(services)

# Endpoint to get cities with laundry services
@app.route("/api/cities")
def get_cities():
    query = """
    PREFIX ex: <http://example.org/e-laundry#>
    PREFIX schema: <http://schema.org/>
    SELECT ?cityName ?placeName
    WHERE {
        ?city a schema:City ;
              schema:name ?cityName ;
              schema:containsPlace ?place .
        ?place schema:name ?placeName .
    }
    """
    results = graph.query(query, initNs={"schema": SCHEMA, "ex": EX})
    cities = {}
    for row in results:
        city = str(row.cityName)
        place = str(row.placeName)
        if city not in cities:
            cities[city] = []
        cities[city].append(place)
    return jsonify(cities)

# Frontend route
@app.route("/")
def index():
    return render_template("index.html")

if __name__ == "__main__":
    app.run(debug=True)
