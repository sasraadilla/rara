import requests
from bs4 import BeautifulSoup

def scrape_laundry_data(url):
    response = requests.get(url)
    soup = BeautifulSoup(response.text, 'html.parser')

    laundry_data = []
    for store in soup.select('.list-business-name'):
        nama = store.text.strip()
        info = store.find_next('ul', class_='list-business-info')
        
        if not info:
            continue
        
        alamat = 'N/A'
        google_map = '#'
        rating = 'N/A'
        nomor_telepon = 'N/A'
        jam_buka = 'N/A'
        ulasan = 'N/A'

        for li in info.find_all('li'):
            strong_tag = li.find('strong')
            if strong_tag:
                key = strong_tag.text.strip()
                value = li.text.replace(key + ':', '').strip()
                if key == 'Alamat':
                    alamat = value
                elif key == 'Google Map':
                    google_map = li.find('a')['href'].strip() if li.find('a') else '#'
                elif key == 'Rating Google':
                    rating = value
                elif key == 'Nomor telepon':
                    nomor_telepon = value
                elif key == 'Jam Buka':
                    jam_buka = value
                elif key == 'Ulasan':
                    ulasan = value

        laundry_data.append({
            'nama': nama,
            'alamat': alamat,
            'google_map': google_map,
            'rating': rating,
            'nomor_telepon': nomor_telepon,
            'jam_buka': jam_buka,
            'ulasan': ulasan
        })

    return laundry_data