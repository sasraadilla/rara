from flask import Flask, render_template, request
from scraper import scrape_laundry_data

app = Flask(__name__)

@app.route('/', methods=['GET', 'POST'])
def index():
    data = []
    if request.method == 'POST':
        url = request.form['url']
        data = scrape_laundry_data(url)
    return render_template('index.html', data=data)

if __name__ == '__main__':
    app.run(debug=True)